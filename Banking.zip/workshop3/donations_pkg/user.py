def login(database, username, password):

    if username in database.keys():
        if password == database[username]:
            print("You are logged in as " + username)
            return username
        else:
            print("You must be logged in to donate")
            return ""
    else:
        print("User not in database")
        return ""


def register(database, username, password):
    if username in database:
        print("Username already registered.")
        return ""
    else:
        database[username] = password
        print("Username has been registered: ", username)
