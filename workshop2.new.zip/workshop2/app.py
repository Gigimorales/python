from banking_pkg import account


def atm_menu():
    print("")
    print("          === Automated Teller Machine ===          ")

while True:
    name = input("enter name to register: ")
    if len(name) < 1 or len > 10 :
        print("The maximum name length is 10 characters.")
        continue
    pin = input("Enter PIN: ")
    if len(pin) < 4 or len(pin) > 4:
        print("")
    balance = float(0)
    print (len(name, "has been registered with a starting balance of $",balance))
    
while True:
    entered_name = input("Name: ")
    entered_pin = input("PIN: ")
    
    if entered_name == name and entered_pin == pin:
        print("Login successful!")
        break

    else:
        print("Invalid credentials!")

while True:
    atm_menu()
    print("User: ", entered_name)
    print("------------------------------------------")
    print("| 1.    Balance     | 2.    Deposit      |")
    print("------------------------------------------")
    print("------------------------------------------")
    print("| 3.    Withdraw    | 4.    Logout       |")
    print("------------------------------------------")
    option = input("Choose an option: ")

    if option == "1":
        account.show_balance(balance)

    elif option == "2":
        balance = account.deposit(balance)
        account.show_balance(balance)

    elif option == "3":
        balance = account.withdraw(balance)
        account.show_balance(balance)

    elif option == "4":
        account.logout(name)
        break

    else:
        print("Unknown option")